package com.green.Await;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwaitApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwaitApplication.class, args);
	}

}
